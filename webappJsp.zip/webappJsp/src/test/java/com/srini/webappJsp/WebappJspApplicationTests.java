package com.srini.webappJsp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebappJspApplicationTests {

	@Test
	void contextLoads() {
	}

}
