package com.srini.webappJsp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebappJspApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebappJspApplication.class, args);
	}

}
